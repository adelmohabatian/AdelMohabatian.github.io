# WebSocial v1.3 — Editorial profiles and cross-links

- Added standalone bilingual book pages for Fruit Vendors, Goffman translation, and Shahsavan book in preparation.
- Expanded Films and Photography with research-led editorial structures; no invented credits or images.
- Added cross-links to Publications and About.
- Kept shared language.js and default English.
- Removed PDFs from the release, per project decision. No PDF links promised in this version.
- Deployment: replace releases/site.zip with the contents of this full ZIP using existing GitHub Actions workflow.

## v1.5
- Verified user-supplied ISBNs, subtitles, publishers, and purchase links added to two book profiles.
- Bilingual purchase links and metadata on Publications.
- No journal article PDFs bundled.

## v1.7 — Editorial Navigation
- Added bilingual breadcrumbs on every internal page.
- Added contextual cross-links between research, papers, books, film and photography.
- Made publication list titles clickable where corresponding article pages exist.
- Added skip-to-content accessibility link and active navigation state.
- Preserved English/Persian persistence and kept PDFs out of this lightweight package.


## v1.8 — Film dossier & photography editorial
- New /films/shahsavan/ film dossier, with unverified festival metadata withheld.
- Reworked /films/ into a concise film index.
- Reworked /photography/ into an editorial outline without invented or placeholder images.
- Preserved sitewide EN/FA state and PDF-free lightweight release.

## v1.9
- Added original film poster and 18 optimized field photographs.
- Bilingual film presentation and photographic gallery, retaining shared language switch.
- Kept the home page minimalist and excluded article PDFs.
