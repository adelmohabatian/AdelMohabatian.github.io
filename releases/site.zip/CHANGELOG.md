# WebSocial v1.3 — Editorial profiles and cross-links

- Added standalone bilingual book pages for Fruit Vendors, Goffman translation, and Shahsavan book in preparation.
- Expanded Films and Photography with research-led editorial structures; no invented credits or images.
- Added cross-links to Publications and About.
- Kept shared language.js and default English.
- Removed PDFs from the release, per project decision. No PDF links promised in this version.
- Deployment: replace releases/site.zip with the contents of this full ZIP using existing GitHub Actions workflow.

## v1.5
- Verified user-supplied ISBNs, subtitles, publishers, and purchase links added to two book profiles.
- Bilingual purchase links and metadata on Publications.
- No journal article PDFs bundled.
