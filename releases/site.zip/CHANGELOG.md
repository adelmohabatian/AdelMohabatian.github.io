# WebSocial v0.9

- Added a dedicated bilingual Shahsavan research dossier at `/research/shahsavan/`.
- Linked the dossier from the homepage Research section.
- Preserved both article pages and the existing first-paper PDF.
- Kept the second paper as DOI-only pending the final publisher PDF.
- No private field data included.
