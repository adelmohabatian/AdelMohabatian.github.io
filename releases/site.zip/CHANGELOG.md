# WebSocial v0.8
- Added two dedicated publication pages.
- Added self-hosted first published PDF with in-browser viewer and download.
- Added second publisher and DOI access; PDF pending final published file.
- Kept original v0.7 homepage layout and portrait.
