# WebSocial v1.1

- Added full bilingual About & CV page based on supplied 1405 academic resume.
- Added dedicated bilingual Publications index with journal links and books.
- Extracted shared language behavior into /assets/js/language.js for all four existing pages and two new pages.
- Linked home navigation to dedicated pages.
- Preserved all existing PDF assets and research dossier.
- Degree status, film credits and English journal titles remain pending verification.
