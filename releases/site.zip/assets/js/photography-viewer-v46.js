(function(){
const dataURL='/assets/data/photography-galleries-v46.json';
function language(){return document.documentElement.lang==='fa'?'fa':'en'}
function init(el,items){if(!items||!items.length)return;let idx=0,active=0;
const stage=document.createElement('div');stage.className='ws-photo-stage';
const imgs=[new Image(),new Image()];imgs.forEach(im=>{im.decoding='async';stage.appendChild(im)});
const ctr=document.createElement('div');ctr.className='ws-photo-controls';
const prev=document.createElement('button'),next=document.createElement('button'),counter=document.createElement('span');counter.className='ws-photo-count';
const caption=document.createElement('div');caption.className='ws-photo-caption';caption.setAttribute('aria-live','polite');
ctr.append(prev,counter,next);el.append(stage,ctr,caption);
function labels(){const fa=language()==='fa';prev.textContent=fa?'قبلی':'Previous';next.textContent=fa?'بعدی':'Next';counter.textContent=String(idx+1).padStart(2,'0')+' / '+String(items.length).padStart(2,'0');caption.textContent=items[idx][fa?'fa':'en'];imgs[active].alt=items[idx][fa?'alt_fa':'alt_en']||caption.textContent;}
let token=0;
function show(n,instant=false){idx=(n+items.length)%items.length;let seq=++token;let other=1-active;let im=imgs[other];im.onload=()=>{if(seq!==token)return;im.classList.add('is-visible');imgs[active].classList.remove('is-visible');active=other;labels()};im.onerror=()=>{if(seq===token){caption.textContent=language()==='fa'?'تصویر بارگذاری نشد.':'Image could not load.'}};im.src=items[idx].src;if(im.complete&&im.naturalWidth)im.onload();}
prev.onclick=()=>show(idx-1);next.onclick=()=>show(idx+1);
let x=null;stage.addEventListener('touchstart',e=>{x=e.touches[0].clientX},{passive:true});stage.addEventListener('touchend',e=>{if(x===null)return;const d=e.changedTouches[0].clientX-x;if(Math.abs(d)>45)show(idx+(d<0?1:-1));x=null},{passive:true});
el.tabIndex=0;el.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();show(idx+(e.key==='ArrowRight'?1:-1))}});
const observer=new MutationObserver(labels);observer.observe(document.documentElement,{attributes:true,attributeFilter:['lang','dir']});show(0,true);
}
fetch(dataURL).then(r=>{if(!r.ok)throw Error('Gallery manifest unavailable');return r.json()}).then(data=>document.querySelectorAll('[data-ws-viewer]').forEach(el=>init(el,data[el.dataset.wsViewer]))).catch(e=>console.warn('Photo viewer:',e.message));
})();