# WebSocial v0.9

Complete static site archive for GitHub Actions. Upload the ZIP as `releases/site.zip` (replace the previous file). Do not extract in the GitHub repository. The site is published from the workflow temporary build directory.

New page: `/research/shahsavan/`. All prior paths preserved.
