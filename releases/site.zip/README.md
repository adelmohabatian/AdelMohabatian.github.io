# WebSocial v1.1

Upload this entire ZIP as `releases/site.zip` using the existing GitHub Actions workflow. Do not unzip into the repository. Includes the full v1.0 site, article PDF, About/CV and Publications library.
