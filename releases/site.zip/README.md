# WebSocial v0.8 — Publications

Upload the **contents** of this folder to the root of `AdelMohabatian.github.io`, preserving the directory structure.

- The first journal PDF is included at `assets/papers/shahsavan-embodied-poverty.pdf`.
- The second journal article has a dedicated page and DOI/publisher links, but no self-hosted PDF yet because the final PDF was not supplied.
- Do not upload private field notes.
- For the second PDF, after obtaining the final file, add `assets/papers/shahsavan-bureaucracy.pdf` and update the second article page to include PDF links/viewer.
- Note that the first article PDF has a page-range inconsistency between the supplied bibliographic citation and its internal citation line; verify with publisher.
