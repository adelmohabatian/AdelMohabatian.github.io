WebSocial v5.2 Lightweight Development

This is a development-only snapshot, not a production release.
Each of four Photography project galleries has three entries.
Original archive is unchanged. Do not overwrite production site.zip with this file.
Run locally: extract into a separate folder, cd to it, python -m http.server 8090.
Visit http://127.0.0.1:8090/photography/
Some original Shahsavan images remain because other site pages may reference them.
No automatic changes to Content Studio or GitHub.
